datacache <- new.env(hash=TRUE, parent=emptyenv())

htmg430pmmmentrezg <- function() showQCData("htmg430pmmmentrezg", datacache)
htmg430pmmmentrezg_dbconn <- function() dbconn(datacache)
htmg430pmmmentrezg_dbfile <- function() dbfile(datacache)
htmg430pmmmentrezg_dbschema <- function(file="", show.indices=FALSE) dbschema(datacache, file=file, show.indices=show.indices)
htmg430pmmmentrezg_dbInfo <- function() dbInfo(datacache)

htmg430pmmmentrezgORGANISM <- "Mus musculus"

.onLoad <- function(libname, pkgname)
{
    ## Connect to the SQLite DB
    dbfile <- system.file("extdata", "htmg430pmmmentrezg.sqlite", package=pkgname, lib.loc=libname)
    assign("dbfile", dbfile, envir=datacache)
    dbconn <- dbFileConnect(dbfile)
    assign("dbconn", dbconn, envir=datacache)

    ## Create the OrgDb object
    sPkgname <- sub(".db$","",pkgname)
    txdb <- loadDb(system.file("extdata", paste(sPkgname,
      ".sqlite",sep=""), package=pkgname, lib.loc=libname),
                   packageName=pkgname)    
    dbNewname <- AnnotationDbi:::dbObjectName(pkgname,"ChipDb")
    ns <- asNamespace(pkgname)
    assign(dbNewname, txdb, envir=ns)
    namespaceExport(ns, dbNewname)
        
    ## Create the AnnObj instances
    ann_objs <- createAnnObjs.SchemaChoice("MOUSECHIP_DB", "htmg430pmmmentrezg", "chip htmg430pmmmentrezg", dbconn, datacache)
    mergeToNamespaceAndExport(ann_objs, pkgname)
    packageStartupMessage(AnnotationDbi:::annoStartupMessages("htmg430pmmmentrezg.db"))
}

.onUnload <- function(libpath)
{
    dbFileDisconnect(htmg430pmmmentrezg_dbconn())
}

