datacache <- new.env(hash=TRUE, parent=emptyenv())

mogene20stmmentrezg <- function() showQCData("mogene20stmmentrezg", datacache)
mogene20stmmentrezg_dbconn <- function() dbconn(datacache)
mogene20stmmentrezg_dbfile <- function() dbfile(datacache)
mogene20stmmentrezg_dbschema <- function(file="", show.indices=FALSE) dbschema(datacache, file=file, show.indices=show.indices)
mogene20stmmentrezg_dbInfo <- function() dbInfo(datacache)

mogene20stmmentrezgORGANISM <- "Mus musculus"

.onLoad <- function(libname, pkgname)
{
    ## Connect to the SQLite DB
    dbfile <- system.file("extdata", "mogene20stmmentrezg.sqlite", package=pkgname, lib.loc=libname)
    assign("dbfile", dbfile, envir=datacache)
    dbconn <- dbFileConnect(dbfile)
    assign("dbconn", dbconn, envir=datacache)

    ## Create the OrgDb object
    sPkgname <- sub(".db$","",pkgname)
    txdb <- loadDb(system.file("extdata", paste(sPkgname,
      ".sqlite",sep=""), package=pkgname, lib.loc=libname),
                   packageName=pkgname)    
    dbNewname <- AnnotationDbi:::dbObjectName(pkgname,"ChipDb")
    ns <- asNamespace(pkgname)
    assign(dbNewname, txdb, envir=ns)
    namespaceExport(ns, dbNewname)
        
    ## Create the AnnObj instances
    ann_objs <- createAnnObjs.SchemaChoice("MOUSECHIP_DB", "mogene20stmmentrezg", "chip mogene20stmmentrezg", dbconn, datacache)
    mergeToNamespaceAndExport(ann_objs, pkgname)
    packageStartupMessage(AnnotationDbi:::annoStartupMessages("mogene20stmmentrezg.db"))
}

.onUnload <- function(libpath)
{
    dbFileDisconnect(mogene20stmmentrezg_dbconn())
}

