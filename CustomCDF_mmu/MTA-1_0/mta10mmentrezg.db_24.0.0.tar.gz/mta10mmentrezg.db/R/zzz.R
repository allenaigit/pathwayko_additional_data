datacache <- new.env(hash=TRUE, parent=emptyenv())

mta10mmentrezg <- function() showQCData("mta10mmentrezg", datacache)
mta10mmentrezg_dbconn <- function() dbconn(datacache)
mta10mmentrezg_dbfile <- function() dbfile(datacache)
mta10mmentrezg_dbschema <- function(file="", show.indices=FALSE) dbschema(datacache, file=file, show.indices=show.indices)
mta10mmentrezg_dbInfo <- function() dbInfo(datacache)

mta10mmentrezgORGANISM <- "Mus musculus"

.onLoad <- function(libname, pkgname)
{
    ## Connect to the SQLite DB
    dbfile <- system.file("extdata", "mta10mmentrezg.sqlite", package=pkgname, lib.loc=libname)
    assign("dbfile", dbfile, envir=datacache)
    dbconn <- dbFileConnect(dbfile)
    assign("dbconn", dbconn, envir=datacache)

    ## Create the OrgDb object
    sPkgname <- sub(".db$","",pkgname)
    txdb <- loadDb(system.file("extdata", paste(sPkgname,
      ".sqlite",sep=""), package=pkgname, lib.loc=libname),
                   packageName=pkgname)    
    dbNewname <- AnnotationDbi:::dbObjectName(pkgname,"ChipDb")
    ns <- asNamespace(pkgname)
    assign(dbNewname, txdb, envir=ns)
    namespaceExport(ns, dbNewname)
        
    ## Create the AnnObj instances
    ann_objs <- createAnnObjs.SchemaChoice("MOUSECHIP_DB", "mta10mmentrezg", "chip mta10mmentrezg", dbconn, datacache)
    mergeToNamespaceAndExport(ann_objs, pkgname)
    packageStartupMessage(AnnotationDbi:::annoStartupMessages("mta10mmentrezg.db"))
}

.onUnload <- function(libpath)
{
    dbFileDisconnect(mta10mmentrezg_dbconn())
}

